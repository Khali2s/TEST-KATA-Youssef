package com.kata.enumeration;

public enum TransactionType {
    WITHDRAWAL, DEPOSIT;
}
