package com.kata.domain;

public class Client {

    private String name;

    public Client(String name) {
        this.name = name;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


}
