package com.kata.domain;

import com.kata.printing.StatementPrinter;
import com.kata.transactions.Transactions;

public class Account {

    private final Transactions transactions;
    private final StatementPrinter statementPrinter;
    private final Client client;

    public Account(final StatementPrinter statementPrinter, final Transactions transactions, final Client client) {
        this.transactions = transactions;
        this.statementPrinter = statementPrinter;
        this.client = client;
    }

    public float deposit(final float amount) {
        transactions.recordTransactionOf(amount);
        return amount;
    }

    public float withdraw(final float amount) {
        transactions.recordTransactionOf(-amount);
        return amount;
    }

    public Transactions getTransactions(){
    	return transactions;
    }
    public void printStatement() {
        statementPrinter.print(transactions.statement());
    }
}
