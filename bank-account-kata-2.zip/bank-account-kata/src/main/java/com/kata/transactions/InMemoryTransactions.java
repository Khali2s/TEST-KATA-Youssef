package com.kata.transactions;

import java.util.ArrayList;
import java.util.List;

import com.kata.domain.Statement;
import com.kata.domain.Transaction;
import com.kata.utils.Utils;

public class InMemoryTransactions implements Transactions {

    private final List<Transaction> transactions;
    private final Utils utils;
    private final StatementGenerator statementGenerator;

    public InMemoryTransactions(final Utils utils, StatementGenerator statementGenerator) {
        this.statementGenerator = statementGenerator;
        this.transactions = new ArrayList<>();
        this.utils = utils;
    }

    @Override
    public void recordTransactionOf(final float amount) {
        transactions.add(new Transaction(amount, utils.now()));
    }

    @Override
    public Statement statement() {
        final float INITIAL_BALANCE = 0;
        return statementGenerator.generateStatementFor(transactions, INITIAL_BALANCE);
    }

    public Boolean hasAlreadyRecorded(final Transaction transaction) {
        return transactions.contains(transaction);
    }
}
