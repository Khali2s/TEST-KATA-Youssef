package com.kata.transactions;

import com.kata.domain.Statement;

public interface Transactions {
    
	void recordTransactionOf(float amount);

    Statement statement();
}
