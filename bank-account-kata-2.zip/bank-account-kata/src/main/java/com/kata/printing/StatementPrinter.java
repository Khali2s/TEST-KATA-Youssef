package com.kata.printing;

import com.kata.domain.Statement;

public interface StatementPrinter {
    void print(Statement statement);
}
