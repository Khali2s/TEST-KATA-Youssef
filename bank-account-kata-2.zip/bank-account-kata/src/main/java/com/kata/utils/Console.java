package com.kata.utils;

public class Console {

    public void printLine(String line) {
        System.out.println(line);
    }
}
