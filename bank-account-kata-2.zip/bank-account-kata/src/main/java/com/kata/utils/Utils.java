package com.kata.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public Date now() {
        return new Date();
    }
    
    public static Date getDate(String date) {
    	DateFormat fromFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
			return fromFormat.parse(date);
		} catch (ParseException e) {
			
		}
        return null;
    }
}
