package com.kata.account;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import org.junit.Before;
import org.junit.Test;

import com.kata.domain.Account;
import com.kata.domain.Client;
import com.kata.domain.Statement;
import com.kata.printing.StatementPrinter;
import com.kata.transactions.Transactions;


public class AccountTest {
	
    StatementPrinter statementPrinter;
    private Transactions transactions;
    private Client client;
    private Account account;
    

    @Before
    public void setUp() {
        statementPrinter = mock(StatementPrinter.class);
        transactions = mock(Transactions.class);
        client =  mock(Client.class);
        account = new Account(statementPrinter, transactions, client);
    }

    @Test
    public void test_deposit() {
        account.deposit(100);

        verify(transactions).recordTransactionOf(100);
    }

    @Test
    public void test_withdraw() {
        account.withdraw(100);

        verify(transactions).recordTransactionOf(-100);
    }

    @Test
    public void print_a_statement() {
        account.printStatement();

        verify(transactions).statement();
        verify(statementPrinter).print(any(Statement.class));
    }
}
