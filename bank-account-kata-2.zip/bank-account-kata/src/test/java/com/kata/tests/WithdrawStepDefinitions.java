package com.kata.tests;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.kata.domain.Account;
import com.kata.domain.Client;
import com.kata.printing.ConsoleStatementPrinter;
import com.kata.printing.StatementLineFormatter;
import com.kata.transactions.InMemoryTransactions;
import com.kata.transactions.StatementGenerator;
import com.kata.utils.Console;
import com.kata.utils.Utils;

public class WithdrawStepDefinitions {

	private Console console = new Console();
	private Utils utils = new Utils();
    private Account account;

    
    @Given("^an existing client named \"([^\"]*)\" with (\\d+) EUR in his account$")
    public void an_existing_client_named_name_with_balance_EUR_in_his_account(String name, int balance) throws Throwable {
    	account = new Account(
                 new ConsoleStatementPrinter(console, new StatementLineFormatter()),
                 new InMemoryTransactions(utils, new StatementGenerator()),
                 new Client(name)
         );
        account.deposit(balance);
    }

    @When("^he withdraws (\\d+) EUR from his account$")
    public void he_withdraws_amount_EUR_from_his_account(int amount) throws Throwable {
        account.withdraw(amount);
    }

    @When("^he deposits (\\d+) EUR into his account$")
    public void he_into_amount_EUR_into_his_account(int amount) throws Throwable {
    	account.deposit(amount);    	
    }
    
    @Then("^his new balance is (\\d+) EUR$")
    public void the_new_balance_is_balance_EUR(int balance) throws Throwable {
    	account.printStatement();
    } 

}